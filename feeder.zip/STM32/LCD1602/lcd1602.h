#include"lcd1602.h"
#include"stm32df10x_gpio.h"
#include"stdio.h"
