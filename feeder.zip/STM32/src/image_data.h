/*
 * image_data.h
 *
 *  Created on: 2021��10��18��
 *      Author: SDZZJ
 */

#ifndef IMAGE_DATA_H_
#define IMAGE_DATA_H_

#include <stdint.h>
#define  IMAGE_HEIGHT  160
#define  IMAGE_WIDTH  120

extern const uint16_t image_data[IMAGE_HEIGHT][IMAGE_WIDTH] ;



#endif /* IMAGE_DATA_H_ */
